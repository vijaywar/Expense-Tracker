import React from 'react'
import './Welcome.css'
export default function WelcomeAnimation() {
    return (
        <div className="FlexGrid">
            <h1 className="Welcome">
                <span className="WelcText">Welcome!</span></h1>
            <div className="Animation">A</div>
            <div className="AnimationR">A</div>
        </div>
    )
}
